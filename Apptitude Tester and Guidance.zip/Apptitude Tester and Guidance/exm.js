function check() {



  var c = 0;
  var q1 = document.quiz.question1.value;
  var q2 = document.quiz.question2.value;
  var q3 = document.quiz.question3.value;
  var q4 = document.quiz.question4.value;
  var q5 = document.quiz.question5.value;
  var q6 = document.quiz.question6.value;
  var q7 = document.quiz.question7.value;
  var q8 = document.quiz.question8.value;
  var q9 = document.quiz.question9.value;
  var q10 = document.quiz.question10.value;

  


  var result = document.getElementById('result');
  var quiz = document.getElementById("quiz");



  if (q1 == "Function Overloading") { c++ }
  if (q2 == "none") { c++ }
  if (q3 == "a+=5") { c++ }
  if (q4 == "Silence the address of the rows in an array of the pointer and exchange the pointer") { c++ }
  if (q5 == "none of the above") { c++ }
  if (q6 == "Some garbage value will be returned") { c++ }
  if (q7 == "All the above.") { c++ }
  if (q8 == "*head_ref = prev;") { c++ }
  if (q9 == "Binary search") { c++ }
  if (q10 == "Two pointer") { c++ }
 

  quiz.style.display = "none";


  if (c <= 3) {
      document.write(c);
      document.write("    You are fail");


  } else {
      document.write(c);
      document.write("    You are pass");
  }
}
